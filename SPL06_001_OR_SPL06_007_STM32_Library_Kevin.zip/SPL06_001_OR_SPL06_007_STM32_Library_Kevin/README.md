# SPL06-001
Ardino SPL06-001 Library

This is a work in progress to create a working Arduino library for the SPL06-001 pressure sensor. I am able to get the coefficents, pressure, and temperature readings from the sensor. Need to convert to a standard Arduino library format. Code was developed and tested on an ESP32 microcontroller.

Link to datasheet
https://datasheet.lcsc.com/szlcsc/1912111437_Goertek-SPL06-007_C233787.pdf
